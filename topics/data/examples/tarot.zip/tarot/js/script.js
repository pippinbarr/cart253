/**
 * Tarot
 * Pippin Barr
 * 
 * Some experiments with data representing a Tarot deck
 */

"use strict";

/**
 * tbd.
*/
function setup() {

}


/**
 * tbd.
*/
function draw() {

}