# Starting points


Finding metro tickets on the ground and trying to sell them

**Frog eating flies but it gets harder and harder to catch them**

Swimming lessons but controlling your body is really hard

Crossing the street and it’s busy

Riding a tricycle but the wheel keeps falling off

Shaving people’s heads in beautiful patterns and showing them at an art gallery

Making cups out of clay and seeing what cafe customers say about them

Growing plants that eat you

Keeping a computer mouse as a pet and looking after it

Rewiring a light

Cooking spaghetti with a dog